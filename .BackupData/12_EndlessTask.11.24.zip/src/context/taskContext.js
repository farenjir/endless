import { createContext } from 'react'

export const taskContext = createContext({
    getTodos: [],
    getTodo: "",
    handleCreateNewTodo: () => { },
    handleTodoInput: () => { },
    handleCompletedTodo: () => { },
    handleDeleteTodo: () => { }
});

