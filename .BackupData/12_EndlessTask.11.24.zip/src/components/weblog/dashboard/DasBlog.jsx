import React, { Fragment, useState } from "react";
import { useSelector } from "react-redux";
import { Link } from "react-router-dom";
import { paginate } from "../../../utils/paginate";
import Pagination from "../../common/Pagination";
import NavBlog from "./NavBlog";

const DashBlog = () => {
  // get blogList
  const blogList = useSelector(state => state.posts);
  // pagination
  const [perPage] = useState(6);
  const [currentPage, setCurrentPage] = useState(1);
  const handlePageChange = page => {
    setCurrentPage(page);
  };
  // paginate utils
  const weblogList = paginate(blogList, currentPage, perPage);
  return (
    <Fragment>
      {/* navbar */}
      <NavBlog />
      {/* /navbar */}
      <div className="container-xl-dashboard mt-5">
        <div className="row" style={{ direction: "ltr" }}>
        {weblogList.map(post => (
                  <div
                    key={post._id}
                    className="text-right col-12 col-md-6 col-lg-4"
                  >
                    <div className="mx-auto">
                      <Link
                        to={`/blog-post/${post._id}`}
                      >
                        <img
                          className="img-fluid rounded mb-2"
                          // src={`${config.localApimage}/${post.imageUrl}`}
                          src="/assets/images/react-img.png"
                          alt="تصویر پست یافت نشد"
                        />
                      </Link>
                      <h6 className=" text-uppercase font-weight-bold my-2">
                        {post.title}
                      </h6>
                      <div className="iskill-under mb-4"></div>
                      <div className="clearfix"></div>
                    </div>
                  </div>
                ))}
        </div>
      </div>
      <div className="navbar d-flex justify-content-center align-items-center footer mt-5">
      <Pagination
          objLength={blogList.length}
          currentPage={currentPage}
          perPage={perPage}
          onPageChange={handlePageChange}
        />
      </div>
    </Fragment>
  );
};
export default DashBlog;
