import { applyMiddleware, compose, createStore } from "redux";
//reducers
import { reducers } from "../reducers";
// middleware
import thunk from "redux-thunk";
import { loadingBarMiddleware } from "react-redux-loading-bar"
// init weblog
import { getAllBlogList } from "../actions/blogList";
import { getAllCourses } from "../actions/courses";

export const store = createStore(
    reducers,
    compose(
        applyMiddleware(thunk, loadingBarMiddleware()),
        window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__()
    )
);
// initialize Courses for Main pages
store.dispatch(getAllCourses())
// initialize BlogPost for Main pages
store.dispatch(getAllBlogList());
//subscribe most be diActive after eject project
store.subscribe(() => {
    console.log(store.getState());
})