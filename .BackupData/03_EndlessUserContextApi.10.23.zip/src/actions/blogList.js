import { getBlogList } from "../services/blogServices"

export const getAllBlogList = () => {
    return async dispatch => {
        // get blog list from SERVER
        const { data } = await getBlogList();
        // dispatch data
        await dispatch({
            type: "INIT_WEBLOG",
            payload: data.singlePosts
        });
    }
}

