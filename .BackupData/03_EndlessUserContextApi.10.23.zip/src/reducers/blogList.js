export const BlogListReducer = (state = [], action) => {
    switch (action.type) {
        case "INIT_WEBLOG":
            return [...action.payload];
        default:
            return state;
    }
};

