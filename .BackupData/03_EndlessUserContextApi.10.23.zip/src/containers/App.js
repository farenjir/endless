import React from "react";
import Wallet from "./Wallet";
// router
import { BrowserRouter } from "react-router-dom"
// toastify
import {ToastContainer} from "react-toastify"

const App = () => {
  return (
    <BrowserRouter>
      <Wallet />
      <ToastContainer/>
    </BrowserRouter>
  );
};

export default App;
