export const BlogSinglePostReducer = (state = {}, action) => {
    switch (action.type) {
        case "GET_SINGLPOST":
            return {...action.payload }
        default:
            return state
    }
}