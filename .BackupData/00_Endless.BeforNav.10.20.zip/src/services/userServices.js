import config from "./config.json";
import http from "./httpService";

export const registerUser = user => {
  return http.post(`${config.localApi}/register`, JSON.stringify(user));
};

export const loginUser = user => {
  return http.post(`${config.localApi}/login`, JSON.stringify(user));
};
export const forgotPassword = email => {
  return http.post(`${config.localApi}/forgetpass`, JSON.stringify(email));
};