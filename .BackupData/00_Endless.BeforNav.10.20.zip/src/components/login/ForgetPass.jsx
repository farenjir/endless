import React, { useRef, useState } from "react";
import { Link } from "react-router-dom";
import Helmet from "react-helmet";
import SimpleReactValidator from "simple-react-validator";
import { errorMessage } from "../../utils/messageToast";

const ForgetPass = () => {
  const user = useSelector(state => state.user);
  const dispatch = useDispatch();
  // props(withRouter) for replace user to HomePage
  // set states
  const [email, setEmail] = useState("");
  // validator inputs
  const [, forceUpdate] = useState();
  const validator = useRef(
    new SimpleReactValidator({
      messages: {
        required: "تکمیل این قسمت الزامی است",
        min: "حداقل هشت کارکتر وارد کنید",
        email: "ایمیل وارد شده صحیح نیست",
      },
    })
  );
  // reset data user
  const reset = () => {
    setEmail("");
  };
  // handels
  const handleSubmit = async event => {
    // preventDefualt none
    event.preventDefault();
    // get user values
    const user = {
      email,
    };
    try {
      if (validator.current.allValid()) {
dispatch()
        reset();
          // push user in HomePage
          props.history.replace("/");
        }
      } else {
        validator.current.showMessages();
        forceUpdate(1);
      }
    } catch (ex) {
      errorMessage("ایمیل شما معتبر نیست");
      console.log(ex);
    }
  };
  // return .............................................
  return (
    <div className="container">
            <Helmet>
          <title>کوینومیک | بازیابی کلمه عبور</title>
        </Helmet>
      {/* <!-- info section --> */}
      <section>
        <div className="container">
          <div className="my-5 text-center">
            <h2>Features</h2>
            <p>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc quam
              urna, dignissim nec auctor in, mattis vitae leo.
            </p>
          </div>
        </div>
      </section>
      {/* <!-- /info section --> */}
      {/* <!-- login section --> */}
      <section>
        <div className="row justify-content-center">
          <div className="col-md-10 col-lg-12 ">
            <div className="card shadow-lg o-hidden border-0 my-5">
              <div className="card-body p-0">
                <div className="row">
                  <div className="col-lg-6">
                    <div className="p-5">
                      <div className="text-center">
                        <h4 className="text-dark mb-4"> بازیابی کلمه عبور</h4>
                      </div>
                      <form className="user" onSubmit={handleSubmit}>
                        <div className="form-group">
                          <input
                            className="form-control form-control-user text-right"
                            type="email"
                            aria-describedby="emailHelp"
                            placeholder="آدرس ایمیل"
                            name="email"
                            value={email}
                            onChange={e => setEmail(e.target.value)}
                          />
                        </div>
                        <button
                          className="btn btn-primary btn-block text-white btn-user"
                          type="submit"
                        >
                          ارسال درخواست
                        </button>
                        <hr />
                      </form>
                      <div className="text-center">
                        <Link to="/login" className="small">
                          بازگشت به صفحه ورود
                        </Link>
                      </div>
                      <div className="text-center">
                        <Link to="/register" className="small">
                           ساخت حساب کاربری جدید !{" "}
                        </Link>
                      </div>
                    </div>
                  </div>
                  <div className="col-lg-6 d-none d-lg-flex">
                    <div
                      className="flex-grow-1 bg-login-image"
                      style={{
                        backgroundImage:
                          "url(assets/images/car-american-img.jpeg)",
                      }}
                    ></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      {/* <!-- /login section --> */}
    </div>
  );
};

export default ForgetPass;
