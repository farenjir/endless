import React, { Fragment } from "react";

const Footer = () => {
  return (
    <Fragment>
      {/* <!-- footer --> */}
      <footer>
        <div className="container">
          <div className="row">
            <div className="col-sm-6 col-md-3 my-3">
              <h3 className="mb-4">
                <a href="#">
                  Company<span>logo </span>
                </a>
              </h3>
              <form className="user">
                <div className="form-group">
                  <input
                    className="form-control form-control-user"
                    type="email"
                    aria-describedby="emailHelp"
                    placeholder="Enter Email Address..."
                    name="email"
                  />
                </div>
                {/* <!-- <button className="btn w-25  btn-outline-primary btn-block btn-user" type="submit">Send</button> --> */}
              </form>
            </div>
            <div className="col-sm-6 col-md-3">
              <div className="d-flex justify-content-end">
                <ul className="list-unstyled">
                  <li>
                    <h4>About company</h4>
                  </li>
                  <li>Lorem ipsum dolor</li>
                  <li>Lorem ipsum dolor</li>
                  <li>Lorem ipsum dolor</li>
                  <li>Lorem ipsum dolor</li>
                  <li>Lorem ipsum dolor</li>
                  <li>Lorem ipsum dolor</li>
                </ul>
              </div>
            </div>
            <div className="col-sm-6 col-md-3">
              <div>
                <span className="fas fa-home"> </span>
                <p>
                  <span>21 Revolution Street</span> Paris, France
                </p>
              </div>
              <div>
                <i className="fa fa-phone"></i>
                <p> +1 555 123456</p>
              </div>
              <div>
                <i className="fa fa-envelope footer-contacts-icon"></i>
                <p>
                  {" "}
                  <a href="#" target="_blank">
                    support@company.com
                  </a>
                </p>
              </div>
            </div>
            <div className="clearfix"></div>
            <div className="col-md-3">
              <h4>About the company</h4>
              <p>
                {" "}
                Lorem ipsum dolor sit amet, consectateur adispicing elit. Fusce
                euismod convallis velit, eu auctor lacus vehicula sit amet.{" "}
              </p>
              <div>
                {/* <!-- <a href="#"><i className="fas fa-facebook"></i></a> --> */}
                <a href="#" className="nav-icon">
                  <i className="i-social-icon fab fa-instagram"></i>
                </a>
                <a href="#" className="nav-icon">
                  <i className="i-social-icon fab fa-facebook"></i>
                </a>
                <a href="#" className="nav-icon">
                  <i className="i-social-icon fab fa-twitter"></i>
                </a>
              </div>
            </div>
          </div>
        </div>
      </footer>
      {/* <!-- end footer --> */}
    </Fragment>
  );
};

export default Footer;
