import React, { Fragment } from "react";
import { useSelector } from "react-redux";
import { isEmpty } from "lodash";
import { NavLink } from "react-router-dom";

const TopNav = () => {
  // check login user
  const user = useSelector(state=>state.user)
  return (
    <Fragment>
      {/* topNav */}
      <nav className="navbar px3 navbar-expand-md">
        {/* <!-- navbar --> */}
        <NavLink to="/" exact activeStyle={{ color: "lightpink" }}>
          <i className="mx-1 fas fa-infinity icon-brand"></i>
          {/* <!-- <img className="nav-pills" src="./img/gearLogo.png" alt="Logo" /> --> */}
        </NavLink>
        {/* <!-- navBotton --> */}
        <button
          className="navbar-toggler"
          type="button"
          data-toggle="collapse"
          data-target="#myNav"
        >
          <span className="nav-icon">
            <i className="fas fa-bars"></i>
          </span>
        </button>
        {/* <!-- navbar collaps --> */}
        <div className="navbar-collapse collapse" id="myNav">
          <ul className="navbar-nav mx-auto mt-3 mt-md-0">
            <li className="nav-item icon-under d-none d-md-block">
              <NavLink
                to="/"
                exact
                activeStyle={{ color: "orange" }}
                className="nav-link"
              >
                {"  "}
                صفحه نخست
              </NavLink>
            </li>
            {isEmpty(user) ? (
              <Fragment>
                <li className="nav-item icon-under">
                  <NavLink
                    to="/login"
                    activeStyle={{ color: "orange" }}
                    className="nav-link"
                  >
                    <i className="fas fa-user-check mx-1"></i>
                    {"  "}
                    ورود
                  </NavLink>
                </li>
                <li className="nav-item icon-under">
                  <NavLink
                    to="/register"
                    activeStyle={{ color: "orange" }}
                    className="nav-link"
                  >
                    <i className="fas fa-user-plus mx-1"></i>
                    {"  "}
                    ثبت نام
                  </NavLink>
                </li>
              </Fragment>
            ) : (
              <Fragment>
                <li className="nav-item icon-under">
                  {" "}
                  <NavLink to="/profile" className="nav-link">
                    <i className="fas fa-user mx-1"></i>{" "}
                    {user.fullname}
                  </NavLink>
                </li>
                <li className="nav-item icon-under">
                  {" "}
                  <NavLink to="/logout" className="nav-link">
                    / خروج
                  </NavLink>
                </li>
              </Fragment>
            )}
            <li className="nav-item icon-under">
              {" "}
              <NavLink
                to="/weblog"
                activeStyle={{ color: "orange" }}
                className="nav-link"
              >
                <i className="fas fa-newspaper mx-1"></i>
                {"  "}
                وبلاگ
              </NavLink>
            </li>
            <li className="nav-item icon-under">
              {" "}
              <NavLink
                to="/laws"
                activeStyle={{ color: "orange" }}
                className="nav-link"
              >
                قوانین سایت{" "}
              </NavLink>
            </li>
            <li className="nav-item icon-under">
              {" "}
              <NavLink
                to="/contact-us"
                activeStyle={{ color: "orange" }}
                className="nav-link"
              >
                تماس با ما
              </NavLink>
            </li>
            <li className="nav-item icon-under">
              {" "}
              <NavLink
                to="/about-us"
                activeStyle={{ color: "orange" }}
                className="nav-link"
              >
                درباره ما
              </NavLink>
            </li>
          </ul>
        </div>
        {/* <!-- end navbar --> */}
      </nav>
      {/* / topNav */}
    </Fragment>
  );
};

export default TopNav;
