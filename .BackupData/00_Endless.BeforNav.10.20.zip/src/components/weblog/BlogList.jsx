import React, { Fragment, useState } from "react";
import { Link } from "react-router-dom";
// import config from "../../services/config.json";
// redux
import { useSelector } from "react-redux";
// utils
import Pagination from "../common/Pagination";
import { paginate } from "../../utils/paginate";
import Helmet from "react-helmet";

const BlogList = () => {
  // get blogList
  const blogList = useSelector(state => state.blogList);
  // pagination
  const [perPage] = useState(5);
  const [currentPage, setCurrentPage] = useState(1);
  const handlePageChange = page => {
    setCurrentPage(page);
  };
  // paginate utils
  const weblogList = paginate(blogList, currentPage, perPage);
  return (
    <Fragment>
      <div className="container mt-5">
      <Helmet>
          <title>کوینومیک | خبرنامه</title>
        </Helmet>
        <div className="text-center">
          <h2 className="text-info">وبلاگ کوینومیک</h2>
          <p className="w-75 mx-auto text-success">
            تاکنون مجموعه کوینومیک توانسته با تولید{" "}
            <span className="badge-info badge-pill badge">
              {blogList.length}
            </span>{" "}
            مطلب آموزشی در زمینه ارزدیجیتال شما عزیزان را در این مسیر آگاه نماید
          </p>
        </div>
        <div className="bg-white p-5">
          <div className="row">
            {/* <!-- blog post from SERVER--> */}
            {weblogList.map(post => (
              <div key={post._id} className="row my-3">
                <div className="col-lg-4">
                  <Link to={`/blog-post/${post._id}`}>
                    <img
                      className="rounded img-fluid"
                      src="assets/images/react-img.png"
                      // src={`${config.localApimage}/${post.imageUrl}`}
                    />
                  </Link>
                </div>
                <div className="col-lg-8 my-2 text-right">
                  <h4>{post.title}</h4>
                  <div className="info">
                    <span className="text-muted">
                      {post.date} نویسنده :{" "}
                      <Link to={post.writer}>{post.writer}</Link>
                    </span>
                  </div>
                  <p>{post.info}</p>
                  <Link to={`/blog-post/${post._id}`}>
                    <button
                      className="btn btn-outline-primary btn-sm"
                      type="button"
                    >
                      بیشتر بدانید
                    </button>
                  </Link>
                </div>
              </div>
            ))}
            {/* <!-- /blog post from SERVER --> */}
          </div>
        </div>
        <Pagination
          blogList={blogList.length}
          currentPage={currentPage}
          perPage={perPage}
          onPageChange={handlePageChange}
        />
      </div>
    </Fragment>
  );
};

export default BlogList;
