import React, { Fragment } from "react";
import { Helmet } from "react-helmet";
// main components ( Childeren )
import HomeHeader from "./HomeHeader";
import HomeTitel from "./HomeTitle";
// blog Component
import MainBlog from "../weblog/MainBlog";
// suggest components
import SellSugest from "../common/sellsugest";

const MainContent = () => {
  return (
    <Fragment>
      <Helmet>
        <title>والت | ارز دیجیتال</title>
      </Helmet>
      <HomeHeader />
      <main>
        <HomeTitel />
        <SellSugest />
        <MainBlog />
      </main>
    </Fragment>
  );
};

export default MainContent;
