import { getCourses, newCourse } from "../services/courseSevices"
import { successMessage } from "../utils/messageToast"

export const getAllCourses = () => {
    return async dispatch => {
        const { data } = await getCourses()
        dispatch({
            type: "INIT_COURSES",
            payload: data.courses
        })
    }
}
export const createNewCourse = (course) => {
    return async (dispatch, getState) => {
        const { data, status } = await newCourse(course);
        if (status === 201) successMessage("دوره با موفقیت ساخته شد");
        await dispatch({
            type: "ADD_COURSE",
            payload: [...getState().courses, data.course],
        });
    };
};
