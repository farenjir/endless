import { getBlogList, newSinglePost } from "../services/blogServices"
import { successMessage } from "../utils/messageToast";

export const getAllBlogList = () => {
    return async dispatch => {
        // get blog list from SERVER
        const { data } = await getBlogList();
        // dispatch data
        await dispatch({
            type: "INIT_WEBLOG",
            payload: data.singlePosts
        });
    }
}

export const createNewSinglePost = (singlePost) => {
    return async (dispatch, getState) => {
        const { data, status } = await newSinglePost(singlePost);
        if (status === 201) successMessage("پست با موفقیت ساخته شد");
        await dispatch({
            type: "ADD_POST",
            payload: [...getState().blogList, data.singlePost],
        });
    };
};
