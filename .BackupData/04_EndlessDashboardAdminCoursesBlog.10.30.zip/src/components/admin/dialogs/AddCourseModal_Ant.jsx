import React from "react";
import { useDispatch } from "react-redux";
import {createNewCourse} from "../../../actions/courses"
// antDesign
import { Form, Input, InputNumber, Button, Upload } from "antd";
import { InboxOutlined } from "@ant-design/icons";

const AddCourseModal = ({ closeModal,showModal }) => {
  // dispatch
  const dispatch = useDispatch;
  // form
  const layout = {
    labelCol: {
      span: 8,
    },
    wrapperCol: {
      span: 16,
    },
  };
  const validateMessages = {
    required: `پرکردن این قسمت الزامی است`,
    types: {
      number: `قیمت دوره باید به عدد و تومان باشد`,
    },
    number: {
      range: `حداقل قیمت باید رایگان (0) باشد`,
    },
  };
  //   handels
  const sendData = () => {
    const onFinish = values => {
      dispatch(createNewCourse(values));
      closeModal();
    };
    // upload files
    const normFile = e => {
      console.log("Upload event:", e);
      if (Array.isArray(e)) {
        return e;
      }
      return e && e.fileList;
    }
    // return ................................................................
    return (
      <Form
        {...layout}
        name="course"
        onFinish={onFinish}
        validateMessages={validateMessages}
      >
        <Form.Item
          name="title"
          label="عنوان دوره"
          rules={[
            {
              type: "string",
              required: true,
            },
          ]}
        >
          <Input />
        </Form.Item>
        <Form.Item
          name="info"
          label="توضیحات"
          rules={[
            {
              type: "string",
              required: true,
            },
          ]}
        >
          <Input.TextArea />
        </Form.Item>
        <Form.Item
          name="price"
          label="قیمت دوره"
          rules={[
            {
              required: true,
              type: "number",
              min: 0,
            },
          ]}
        >
          <InputNumber />
        </Form.Item>
        <Form.Item
          name="teacher"
          label="مدرس دوره"
          rules={[
            {
              type: "string",
            },
          ]}
        >
          <Input />
        </Form.Item>
        <Form.Item
          name="time"
          label="زمان دوره"
          //   rules={[
          //     {
          //       type: "number",
          //     },
          //   ]}
        >
          <Input />
        </Form.Item>
        <Form.Item label="Dragger">
          <Form.Item
            name="imageUrl"
            valuePropName="fileList"
            getValueFromEvent={normFile}
            noStyle
          >
            <Upload.Dragger name="imageUrl" action="/upload.do">
              <p className="ant-upload-drag-icon">
                <InboxOutlined />
              </p>
              <p className="ant-upload-text">
                یک عکس آپلود کنید یا آن را به داخل باکس بکشید
              </p>
              <p className="ant-upload-hint">فقط از یک فایل پشتیبانی می شود</p>
            </Upload.Dragger>
          </Form.Item>
        </Form.Item>
        <Form.Item wrapperCol={{ ...layout.wrapperCol, offset: 8 }}>
          <Button type="primary" htmlType="submit">
            آپلود دوره
          </Button>
          <Button type="primary" onClick={closeModal}>
            انصراف
          </Button>
        </Form.Item>
      </Form>
    );
  };
};
export default AddCourseModal;
