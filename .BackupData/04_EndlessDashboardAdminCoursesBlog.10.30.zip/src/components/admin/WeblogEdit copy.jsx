import React from "react";
import { useSelector } from "react-redux";

const WeblogEdit = () => {
  const blogList = useSelector(state=>state.blogList)
  return (
    <div class="row">
      <div class="col text-right">
        <p></p>
        <h1>مدیریت خبرنامه مجموعه اندلس</h1>
        <p>
          Adapted to bootstrap 4 from MUSA's bootstrap 3 . A simple example of
          how-to put a bordered table within a panel. Responsive, place holders
          in header/footer for buttons or pagination.
        </p>
        <p></p>
        <p></p>
        <div class="panel panel-default panel-table">
          <div class="panel-heading">
            <div class="row my-3">
              <div class="col-6 text-right offset-6">
                <button type="button" class="btn btn-sm btn-primary btn-create">
                  ساخت خبر جدید
                </button>
              </div>
            </div>
          </div>
          <div class="panel-body">
            <table class="table table-striped table-bordered table-list" style={{direction:"ltr"}}>
              <thead>
                <tr>
                  <th>اصلاح پست</th>
                  <th  className="d-none d-md-table-cell">زمان انتشار</th>
                  <th>نویسنده</th>
                  <th className="d-none d-md-table-cell">توضیحات</th>
                  <th>عنوان پست</th>
                </tr>
              </thead>
              <tbody>
              {blogList.map(post => (
                  <tr>
                    <td align="center">
                      <button class="btn btn-success mx-1 my-1 my-md-0">
                        <em class="fa fa-cog"></em>
                      </button>
                      <button class="btn btn-danger mx-1">
                        <em class="fa fa-trash"></em>
                      </button>
                    </td>
                    <td className="d-none d-md-table-cell">{post.date}</td>
                    <td>{post.writer}</td>
                    <td
                      className="d-none d-md-table-cell"
                      style={{ maxWidth: "300px" }}
                      >
                      <span
                        class="d-inline-block text-truncate"
                        style={{ maxWidth: "250px" }}
                        >
                        {post.info}
                      </span>
                    </td>
                    <td>{post.title}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
export default WeblogEdit;
