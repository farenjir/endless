import React, { useContext } from "react";
import config from "../../services/config.json";
import Pagination from "../common/Pagination";
import {dashCoursesContext} from "../../context/dashCoursesContext"

const CoursesEdit = ({ courses }) => {
  // context
  const context = useContext(dashCoursesContext);
  const {
    currentPage,
    perPage,
    handlePageChange,
    coursesIndex,
    openNewCourseModal,
  } = context;
  return (
    <div class="row">
      <div class="col text-right">
        <p></p>
        <h1>مدیریت دوره های مجموعه اندلس</h1>
        <p>
          Adapted to bootstrap 4 from MUSA's bootstrap 3 . A simple example of
          how-to put a bordered table within a panel. Responsive, place holders
          in header/footer for buttons or pagination.
        </p>
        <p></p>
        <p></p>
        <div class="panel panel-default panel-table">
          <div class="panel-heading">
            <div class="row my-3">
              <div class="col-6 text-right offset-6">
                <button
                  type="button"
                  class="btn btn-sm btn-primary"
                  onClick={openNewCourseModal}
                >
                  <em class="fa fa-plus-circle mx-2"></em>
                  ساخت دوره جدید
                </button>
              </div>
            </div>
          </div>
          <div class="panel-body">
            <table
              class="table table-striped table-bordered table-list"
              style={{ direction: "ltr" }}
            >
              <thead>
                <tr>
                  <th>اصلاح دوره</th>
                  <th className="d-none d-md-table-cell">زمان دوره</th>
                  <th>عکس دوره</th>
                  <th>مدرس</th>
                  <th> (تومان) قیمت</th>
                  <th className="d-none d-md-table-cell">توضیحات</th>
                  <th>نام دوره</th>
                </tr>
              </thead>
              <tbody>
                {coursesIndex.map(course => (
                  <tr key={course._id}>
                    <td align="center">
                      <button class="btn btn-success mx-1 my-1 my-md-0">
                        <em class="fa fa-cog"></em>
                      </button>
                      <button class="btn btn-danger mx-1">
                        <em class="fa fa-trash"></em>
                      </button>
                    </td>
                    <td className="d-none d-md-table-cell">{course.date}</td>
                    <td align="center">
                      <a
                        href={`${config.localApi}/${course.imageUrl}`}
                        target="_blank"
                        class="btn btn-info my-1 my-md-0"
                      >
                        <em class="fa fa-image"></em>
                      </a>
                    </td>
                    <td>{course.teacher}</td>
                    <td>{course.price === 0 ? "رایگان" : `${course.price}`}</td>
                    <td
                      className="d-none d-md-table-cell"
                      style={{ maxWidth: "300px" }}
                    >
                      <span
                        class="d-inline-block text-truncate"
                        style={{ maxWidth: "250px" }}
                      >
                        {course.info}
                      </span>
                    </td>
                    <td>{course.title}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            <div className="navbar-fixed text-center footer">
              <Pagination
                objLength={courses.length}
                currentPage={currentPage}
                perPage={perPage}
                onPageChange={handlePageChange}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
export default CoursesEdit;
