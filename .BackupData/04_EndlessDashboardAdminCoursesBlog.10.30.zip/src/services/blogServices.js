import config from "./config.json";
import http from "./httpService";

export const getBlogList = () => {
    return http.get(`${config.localApi}/singleposts`)
}

export const getPost = (singlePostId) => {
    return http.get(`${config.localApi}/singlepost/${singlePostId}`)
}

export const newSinglePost = (singlePost) => {
    return http.post(`${config.localApi}/singlepost`, singlePost);
};

export const deleteSinglePost = (singlePostId) => {
    return http.delete(`${config.localApi}/singlepost/${singlePostId}`);
};

export const updateSinglePost = (singlePostId, singlePost) => {
    return http.put(`${config.localApi}/singlepost/${singlePostId}`, singlePost);
};