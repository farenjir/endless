import React, { useState } from "react";
import { paginate } from "../utils/paginate";
import { dashBlogListContext } from "./dashBlogContext";
import AddPostModal from "../components/admin/dialogs/AddPostModal";

const CoursesContext = ({ blogList, children }) => {
  // dialogs course
  const [newSinglePostModal, setNewSinglePostModal] = useState(false);
  const openNewSinglePostModal = () => setNewSinglePostModal(true);
  const closeNewSinglePostModal = () => setNewSinglePostModal(false);
  // pagination
  const [perPage] = useState(7);
  const [currentPage, setCurrentPage] = useState(1);
  const handlePageChange = page => {
    setCurrentPage(page);
  };
  // paginate utils
  const blogListIndex = paginate(blogList, currentPage, perPage);
  //   return ..........................................................
  return (
    <dashBlogListContext.Provider
      value={{
        currentPage,
        perPage,
        handlePageChange,
        blogListIndex,
        openNewSinglePostModal,
      }}
    >
      <AddPostModal
        showModal={newSinglePostModal}
        closeModal={closeNewSinglePostModal}
      />
      {children}
    </dashBlogListContext.Provider>
  );
};
export default CoursesContext;
