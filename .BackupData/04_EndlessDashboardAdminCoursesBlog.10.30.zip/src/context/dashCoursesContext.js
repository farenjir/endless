import { createContext } from 'react'

export const dashCoursesContext = createContext({
    currentPage: 1,
    setCurrentPage: () => { },
    perPage: 5,
    handlePageChange: () => { },
    currentCourse: {},
    setSearch: () => { },
    openNewCourseModal: () => { },
    openEditCourseModal: () => { },
    openDeleteCourseModal: () => { },
    coursesIndex: [],
    filteredCourses: [],
    sortCoursesAsc: () => { },
    sortCoursesDes: () => { },
});

