import React, { useState } from "react";
import { paginate } from "../utils/paginate";
import {dashCoursesContext} from "./dashCoursesContext";
import AddCourseModal from "../components/admin/dialogs/AddCourseModal";

const  CoursesContext = ({ courses, children }) => {
  // dialogs course
  const [newCourseModal, setNewCourseModal] = useState(false);
    const openNewCourseModal = () => setNewCourseModal(true);
    const closeNewCourseModal = () => setNewCourseModal(false);
  // pagination
  const [perPage] = useState(7);
  const [currentPage, setCurrentPage] = useState(1);
  const handlePageChange = page => {
    setCurrentPage(page);
  };
  // paginate utils
  const coursesIndex = paginate(courses, currentPage, perPage);
  //   return ..........................................................
  return (
    <dashCoursesContext.Provider
      value={{
        currentPage,
        perPage,
        handlePageChange,
        coursesIndex,
        openNewCourseModal,
      }}
    >
      <AddCourseModal showModal={newCourseModal} closeModal={closeNewCourseModal}/>
      {children}
    </dashCoursesContext.Provider>
  );
};
export default CoursesContext;

