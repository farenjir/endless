import { createContext } from 'react'

export const dashBlogListContext = createContext({
    currentPage: 1,
    setCurrentPage: () => { },
    perPage: 5,
    handlePageChange: () => { },
    currentSinglePost: {},
    setSearch: () => { },
    openNewSinglePostModal: () => { },
    openEditSinglePostModal: () => { },
    openDeleteSinglePostModal: () => { },
    blogListIndex: [],
    filteredBlogList: [],
    sortBlogListAsc: () => { },
    sortBlogListDes: () => { },
});

