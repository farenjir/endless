import { deleteSinglePost, getBlogList, newSinglePost, updateSinglePost } from "../services/blogServices"
import { successMessage, warningMessage } from "../utils/messageToast";

export const getAllBlogList = () => {
    return async dispatch => {
        const { data } = await getBlogList();
        try {
            await dispatch({
                type: "INIT_WEBLOG",
                payload: data.singlePosts
            });
        } catch (ex) {
            console.log(ex)
        }
    }
}

export const createNewSinglePost = (singlePost) => {
    return async (dispatch, getState) => {
        const blogList = [...getState().blogList]
        try {
            const { data, status } = await newSinglePost(singlePost);
            if (status === 201) successMessage("پست با موفقیت ساخته شد");
            await dispatch({
                type: "ADD_POST",
                payload: [...blogList, data.singlePost],
            });
        } catch (ex) {
            await dispatch({
                type: "ADD_POST",
                payload: [...blogList],
            });
        }
    };
};

export const handleSinglPostUpdate = (singlePostId, updatedSinglePost) => {
    return async (dispatch, getState) => {
        const blogList = [...getState().blogList]
        const filteredBlogList = blogList.filter(singlePost => singlePost._id !== singlePostId)
        try {
            const { data, status } = await updateSinglePost(singlePostId, updatedSinglePost)
            await dispatch({
                type: "UPDATE_POST",
                payload: [data.singlePost, ...filteredBlogList],
            });
            if (status === 200) {
                successMessage("پست با موفقیت به روزرسانی شد")
            }
        } catch (ex) {
            await dispatch({ type: "UPDATE_POST", payload: [...blogList] });
        }
    }
}

export const handleSinglePostDelete = (singlePostId) => {
    return async (dispatch, getState) => {
        const blogList = [...getState().blogList]
        const filteredBlogList = blogList.filter(singlePost => singlePost._id !== singlePostId)
        try {
            await dispatch({
                type: "DELETE_POST",
                payload: [...filteredBlogList]
            })
            const { status } = await deleteSinglePost(singlePostId)
            if (status === 200) {
                warningMessage("دوره با موفقیت حذف شد")
            }
        } catch (ex) {
            await dispatch({
                type: "DELETE_POST",
                payload: [...blogList]
            })
        }
    }
}
