import React from "react";
import { Helmet } from "react-helmet";
// main components ( Childeren )
import HomeHeader from "./HomeHeader";
import HomeTitel from "./HomeTitle";
// blog Component
import MainBlog from "../weblog/MainBlog";
// suggest components
import SellSugest from "../common/Suggest";
import MainCourses from "../course/MainCourses";

const MainContent = () => {
  return (
    <main>
      <Helmet>
        <title> اندلس| ارز دیجیتال</title>
      </Helmet>
      <HomeHeader />
      <HomeTitel />
      <MainCourses />
      <SellSugest />
      <MainBlog />
    </main>
  );
};

export default MainContent;
