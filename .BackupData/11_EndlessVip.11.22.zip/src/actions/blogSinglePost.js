import { getPost } from "../services/blogServices"

export const getSinglePost = (singlePostId) => {
    return async dispatch => {
        // get post from SERVER
        const { data } = await getPost(singlePostId);
        // dispatch data
        await dispatch({ type: "GET_SINGLPOST", payload: data.singlePost });
    }
}

