import React, { useState } from "react";
import { useDispatch } from "react-redux";
import { DialogOverlay, DialogContent } from "@reach/dialog";
import  {createNewSinglePost}  from "../../../actions/blogList";

const AddPostModal = ({ showModal, closeModal }) => {
  const [title, setTitle] = useState();
  const [writer, setWriter] = useState();
  const [info, setInfo] = useState();
  const dispatch = useDispatch();
  // handels
  const handleSubmit = event => {
    event.preventDefault();
    try {
      let data = new FormData();
      data.append("title", title);
      data.append("writer", writer);
      data.append("imageUrl", event.target.imageUrl.files[0]);
      data.append("info", info);
      //Dispatch
      dispatch(createNewSinglePost(data));
      closeModal();
    } catch (ex) {
      console.log(ex);
    }
  };
  return (
    <DialogOverlay
      isOpen={showModal}
      onDismiss={closeModal}
      style={{ direction: "rtl" }}
    >
      <DialogContent
        style={{
          border: "solid 5px hsla(0, 0%, 0%, 0.5)",
          borderRadius: "10px",
          boxShadow: "0px 10px 50px hsla(0, 0%, 0%, 0.33)",
        }}
      >
        <div className="inner form-layer">
          <form onSubmit={handleSubmit}>
            <input
              type="text"
              name="title"
              style={{ marginBottom: 3 }}
              className="form-control"
              placeholder="عنوان پست"
              aria-describedby="title"
              value={title}
              onChange={e => setTitle(e.target.value)}
            />
            <input
              type="text"
              name="writer"
              style={{ marginBottom: 3 }}
              className="form-control"
              placeholder="نویسنده"
              aria-describedby="writer"
              value={writer}
              onChange={e => setWriter(e.target.value)}
            />
            <textarea
              name="info"
              placeholder="توضیحات دوره"
              className="form-control"
              style={{ marginBottom: 3 }}
              value={info}
              onChange={e => setInfo(e.target.value)}
            />
            <input
              type="file"
              name="imageUrl"
              className="form-control my-3"
              aria-describedby="imageUrl"
            />
            <div className="d-flex justify-content-end align-items-center">
              <button type="submit" className="btn btn-success btn-sm mx-1">
                ثبت پست
              </button>
              <button
                className="btn btn-outline-warning btn-sm mx-1"
                onClick={closeModal}
              >
                انصراف
              </button>
            </div>
          </form>
        </div>
      </DialogContent>
    </DialogOverlay>
  );
};

export default AddPostModal;
