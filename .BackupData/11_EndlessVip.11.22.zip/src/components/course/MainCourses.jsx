import React, { Fragment } from "react";
import { useSelector } from "react-redux";
import { Link } from "react-router-dom";
import { paginate } from "../../utils/paginate";

const MainCourses = () => {
  const courses = useSelector(state => state.courses);
  const coursesIndex = paginate(courses, 1, 6);
  return (
    <Fragment>
      {/* <!-- MainBlog --> */}
      <section className="skilld my-5">
        <div className="container">
          <div className="col-12">
            {/* <!-- title section --> */}
            <div className="col-12 mt-5 mb-3">
              <div className="row text-right">
                <div className="col-12 mx-3">
                  <h3>
                    <Link to="/courses" className="text-success">
                      دوره های اندلس
                    </Link>
                  </h3>
                </div>
              </div>
            </div>
            {/* <!-- title section --> */}
            <div className="container">
              <div className="row">
                {/* <!-- blogPost from SERVER --> */}
                {coursesIndex.map(course => (
                  <div
                    key={course._id}
                    className="text-right col-12 col-md-6 col-lg-4"
                  >
                    <div className="mx-auto">
                      <Link to={`/course/${course._id}`}>
                        <img
                          className="img-fluid rounded mb-2"
                          // src={`${config.localApimage}/${course.imageUrl}`}
                          src="assets/images/imageAple.jpg"
                          alt="تصویر دوره یافت نشد"
                        />
                      </Link>
                      <h6 className=" text-uppercase font-weight-bold my-2">
                        {course.title}
                      </h6>
                      <div className="iskill-under mb-4"></div>
                      <div className="clearfix"></div>
                    </div>
                  </div>
                ))}
                {/* <!-- end blogPost --> */}
              </div>
            </div>
          </div>
        </div>
      </section>
      {/* <!-- end MainBlog --> */}
      {/* <!-- title section --> */}
      <section>
        <div className="col-12 mb-5">
          {/* <!-- section info --> */}
          <div className="row text-center">
            <div className="col-12">
              <h3>Lorem ipsum dolor sit amet</h3>
            </div>
            <div className="col-12">
              <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit.
                Sapiente, quo elit. Sapiente, quo
              </p>
              <h4>etur adipisicing elit. Sapiente</h4>
            </div>
          </div>
        </div>
      </section>
      {/* <!-- title section --> */}
    </Fragment>
  );
};
export default MainCourses;
