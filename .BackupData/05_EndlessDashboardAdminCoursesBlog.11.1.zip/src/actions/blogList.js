import { getBlogList, newSinglePost, updateSinglePost } from "../services/blogServices"
import { successMessage } from "../utils/messageToast";

export const getAllBlogList = () => {
    return async dispatch => {
        const { data } = await getBlogList();
        await dispatch({
            type: "INIT_WEBLOG",
            payload: data.blogList
        });
    }
}

export const createNewSinglePost = (singlePost) => {
    return async (dispatch, getState) => {
        const { data, status } = await newSinglePost(singlePost);
        if (status === 201) successMessage("پست با موفقیت ساخته شد");
        await dispatch({
            type: "ADD_POST",
            payload: [...getState().blogList, data.singlePost],
        });
    };
};

export const handleSinglPostUpdate = (singlePostId, updatedSinglePost) => {
    return async (dispatch, getState) => {
        const blogList = [...getState().blogList]
        const updatedBlogList = [...blogList];
        // find singlePost
        const singlePostIndex = updatedBlogList.findIndex(singlePost => singlePost._id === singlePostId)
        let singlePost = updatedBlogList[singlePostIndex];
        // updated
        singlePost = { ...Object.fromEntries(updatedSinglePost) };
        updatedBlogList[singlePostIndex] = singlePost;
        // dispatch data
        try {
            // first update singlePost
            await dispatch({
                type: "UPDATE_POST",
                payload: [...updatedBlogList],
            });
            // next post
            const { data, status } = await updateSinglePost(singlePostId, updatedSinglePost)
            // console.log(data)
            if (status === 200) {
                successMessage("پست با موفقیت به روزرسانی شد")
            }
        } catch (ex) {
            await dispatch({ type: "UPDATE_POST", payload: [...blogList] });
        }
    }
}
