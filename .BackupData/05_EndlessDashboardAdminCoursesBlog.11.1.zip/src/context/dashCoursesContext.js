import { createContext } from 'react'

export const dashCoursesContext = createContext({
    currentPage: 1,
    setCurrentPage: () => { },
    perPage: 5,
    handlePageChange: () => { },
    currentCourse: {},
    openNewCourseModal: () => { },
    openEditCourseModal: () => { },
    openDeleteCourseModal: () => { },
    coursesIndex: [],
    setSearch: () => { },
    filteredCourses: [],
    sortCoursesAsc: () => { },
    sortCoursesDes: () => { },
});

