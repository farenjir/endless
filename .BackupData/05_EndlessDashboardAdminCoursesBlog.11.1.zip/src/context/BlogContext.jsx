import React, { useState } from "react";
import { paginate } from "../utils/paginate";
import { dashBlogContext } from "./dashBlogContext";
import AddPostModal from "../components/admin/modals/AddPostModal";
import EditPostModal from "../components/admin/modals/EditPostModal";

const BlogContext = ({ blogList, children }) => {
  // dialogs singlePost
  const [newSinglePostModal, setNewSinglePostModal] = useState(false);
  const openNewSinglePostModal = () => setNewSinglePostModal(true);
  const closeNewSinglePostModal = () => setNewSinglePostModal(false);
  // singlePost updateEdit
  const [currentSinglePost, setCurrentSinglePost] = useState({});
  const [editSinglePostModal, setEditSinglePostModal] = useState(false);
  const openEditSinglePostModal = singlePost => {
    setEditSinglePostModal(true);
    setCurrentSinglePost(singlePost);
  };
  const closeEditSinglePostModal = () => {
    setEditSinglePostModal(false);
  };
  // pagination
  const [perPage] = useState(7);
  const [currentPage, setCurrentPage] = useState(1);
  const handlePageChange = page => {
    setCurrentPage(page);
  };
  // paginate utils
  const blogListIndex = paginate(blogList, currentPage, perPage);
  //   return ..........................................................
  return (
    <dashBlogContext.Provider
      value={{
        currentPage,
        perPage,
        handlePageChange,
        blogListIndex,
        openNewSinglePostModal,
        openEditSinglePostModal,
      }}
    >
      <AddPostModal
        showModal={newSinglePostModal}
        closeModal={closeNewSinglePostModal}
      />
      <EditPostModal
        showModal={editSinglePostModal}
        closeModal={closeEditSinglePostModal}
        post={currentSinglePost}
      />
      {children}
    </dashBlogContext.Provider>
  );
};
export default BlogContext;
