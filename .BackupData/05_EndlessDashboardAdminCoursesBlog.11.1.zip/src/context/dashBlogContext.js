import { createContext } from 'react'

export const dashBlogContext = createContext({
    currentPage: 1,
    setCurrentPage: () => { },
    perPage: 5,
    handlePageChange: () => { },
    currentSinglePost: {},
    openNewSinglePostModal: () => { },
    openEditSinglePostModal: () => { },
    openDeleteSinglePostModal: () => { },
    blogListIndex: [],
    setSearch: () => { },
    filteredBlogList: [],
    sortBlogListAsc: () => { },
    sortBlogListDes: () => { },
});

