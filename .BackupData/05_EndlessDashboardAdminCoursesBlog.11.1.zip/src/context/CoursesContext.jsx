import React, { useState } from "react";
import { paginate } from "../utils/paginate";
import { dashCoursesContext } from "./dashCoursesContext";
import AddCourseModal from "../components/admin/modals/AddCourseModal";
import EditCourseModal from "../components/admin/modals/EditCourseModal";

const CoursesContext = ({ courses, children }) => {
  // dialogs course
  const [newCourseModal, setNewCourseModal] = useState(false);
  const openNewCourseModal = () => setNewCourseModal(true);
  const closeNewCourseModal = () => setNewCourseModal(false);
  // course updateEdit
  const [currentCourse, setCurrentCourse] = useState({});
  const [editCourseModal, setEditCourseModal] = useState(false);
  const openEditCourseModal = course => {
    setEditCourseModal(true);
    setCurrentCourse(course);
  };
  const closeEditCourseModal = () => {
    setEditCourseModal(false);
  };
  // pagination
  const [perPage] = useState(7);
  const [currentPage, setCurrentPage] = useState(1);
  const handlePageChange = page => {
    setCurrentPage(page);
  };
  // paginate utils
  const coursesIndex = paginate(courses, currentPage, perPage);
  //   return ..........................................................
  return (
    <dashCoursesContext.Provider
      value={{
        currentPage,
        perPage,
        handlePageChange,
        coursesIndex,
        openNewCourseModal,
        openEditCourseModal,
      }}
    >
      <AddCourseModal
        showModal={newCourseModal}
        closeModal={closeNewCourseModal}
      />
      <EditCourseModal
        showModal={editCourseModal}
        closeModal={closeEditCourseModal}
        course={currentCourse}
      />
      {children}
    </dashCoursesContext.Provider>
  );
};
export default CoursesContext;
