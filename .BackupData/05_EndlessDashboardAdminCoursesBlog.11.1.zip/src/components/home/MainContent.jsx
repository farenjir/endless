import React from "react";
import { Helmet } from "react-helmet";
// main components ( Childeren )
import HomeHeader from "./HomeHeader";
import HomeTitel from "./HomeTitle";
// blog Component
import MainBlog from "../weblog/MainBlog";
// suggest components
import SellSugest from "../common/Suggest";
import MainCourses from "../course/MainCourses";
import { Link } from "react-router-dom";

const MainContent = () => {
  return (
    <main>
      <Helmet>
        <title>والت | ارز دیجیتال</title>
      </Helmet>
      <HomeHeader />
      <HomeTitel />
      <MainCourses />
      <SellSugest />
      <MainBlog />
      <Link class="border rounded d-inline scroll-to-top">
        <i class="fas fa-angle-up"></i>
      </Link>
    </main>
  );
};

export default MainContent;
