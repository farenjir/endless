// window.addEventListener('load',()=> document.querySelector('.preloader')
// .classList.add('hidePreloader'));