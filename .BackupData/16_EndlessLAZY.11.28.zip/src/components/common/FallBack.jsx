import React from "react";

const FallBack = () => {
  return (
    <div className="preloader d-flex justify-content-center align-items-center">
      <img src="/assets/imges/preloader.gif" alt="preloader" />
    </div>
  );
};
export default FallBack;
