import React from "react";
import { StrictMode } from "react";
import { Suspense } from "react";
import { render } from "react-dom";
import { Provider } from "react-redux";
// App Store
import App from "./containers/App";
import { store } from "./store";
// fallback
import FallBack from "./components/common/FallBack";

render(
  <Suspense fallback={FallBack}>
    <StrictMode>
      <Provider store={store}>
        <App />
      </Provider>
    </StrictMode>
  </Suspense>
  ,
  document.getElementById("root")
);
