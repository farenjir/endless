import React, { useEffect, lazy } from "react";
// redux
import { useDispatch, useSelector } from "react-redux";
// router
import { Switch, Route, Redirect } from "react-router-dom";
// context
import UserContext from "../context/providers/UserContext";
import DashContext from "../context/providers/DashContext";
import BlogContext from "../context/providers/BlogContext";
import TaskContext from "../context/providers/TaskContext";
import CoursesContext from "../context/providers/CoursesContext";
// jwt
import { addUser, clearUser } from "../actions/user";
import { isEmpty } from "lodash";
// utils
import { decodeToken } from "../utils/decodeToken";
//Layouts
import DashboardLayout from "../components/layouts/DashboardLayout";
import Dashboard from "../components/home/Dashboard";
import MainLayout from "../components/layouts/MainLayout";
import MainContent from "../components/home/MainContent";
// common pages
import Logout from "../components/login/Logout";
import NotFound404 from "../components/common/NotFound404";
// get users for dashAdmin
import { getAllUsers } from "../actions/users";
import { store } from "../store/index";

const Endless = () => {
  // use lazy for  other pages
  const Login = lazy(() => import("../components/login/Login"));
  const Profile = lazy(() => import("../components/profile/Profile"));
  const Register = lazy(() => import("../components/register/Register"));
  const BlogList = lazy(() => import("../components/weblog/BlogList"));
  const About = lazy(() => import("../components/about/About"));
  const ContactUs = lazy(() => import("../components/contact/ContactUs"));
  const Laws = lazy(() => import("../components/laws/Laws"));
  const BlogPost = lazy(() => import("../components/weblog/BlogPost"));
  const ForgetPass = lazy(() => import("../components/login/ForgetPass"));
  const Courses = lazy(() => import("../components/course/Courses"));
  const Course = lazy(() => import("../components/course/Course"));
  const DashBlog = lazy(() => import("../components/weblog/dashboard/DasBlog"));
  const MainBuyVip = lazy(() => import("../components/vip/MainBuyVip"));
  // adminDash
  const WeblogEdit = lazy(() => import("../components/admin/WeblogEdit"));
  const CoursesEdit = lazy(() => import("../components/admin/CoursesEdit"));
  const UserManage = lazy(() => import("../components/admin/UserManage"));
  // user dashboard
  const BuyVip = lazy(() => import("../components/vip/BuyVip"));
  const DashCourses = lazy(() => import("../components/course/dashboard/DashCourses"));
  const DashTask = lazy(() => import("../components/task/DashTask"));
  // dispatch
  const user = useSelector(state => state.user);
  const dispatch = useDispatch();
  // initialize users for AdminDashboard
  if (!isEmpty(user) && user.isAdmin) {
    store.dispatch(getAllUsers());
  }
  // check token
  useEffect(() => {
    const checkToken = () => {
      const token = localStorage.getItem("token");
      if (token) {
        const decodedToken = decodeToken(token);
        const dateNow = Math.floor(Date.now() / 1000);
        if (decodedToken.payload.exp < dateNow) {
          localStorage.removeItem("token");
          dispatch(clearUser());
        } else {
          dispatch(addUser(decodedToken.payload.user));
        }
      }
    };
    // RUN
    checkToken();
  }, []);

  return (
    <Switch>
      <Route path={["/dashboard"]}>
        {/* dashboard ........................................ */}
        <DashboardLayout>
          <Route
            path="/dashboard"
            exact
            render={() =>
              !isEmpty(user) ? <Dashboard /> : <Redirect to="/" />
            }
          />
          <Route
            path="/dashboard/tasks"
            render={() =>
              isEmpty(user) ? (
                <Redirect to="/" />
              ) : (
                <TaskContext>
                  <DashTask />
                </TaskContext>
              )
            }
          />
          <Route
            path="/dashboard/vip"
            render={() => (!isEmpty(user) ? <BuyVip /> : <Redirect to="/" />)}
          />
          <Route
            path="/dashboard/courses"
            render={() =>
              !isEmpty(user) ? (
                <DashContext>
                  <DashCourses />
                </DashContext>
              ) : (
                <Redirect to="/" />
              )
            }
          />
          <Route
            path="/dashboard/weblog"
            render={() =>
              !isEmpty(user) ? (
                <DashContext>
                  <DashBlog />
                </DashContext>
              ) : (
                <Redirect to="/" />
              )
            }
          />
          <Route
            path="/dashboard/editcourses"
            render={() =>
              !isEmpty(user) && user.isAdmin ? (
                <CoursesContext>
                  <CoursesEdit />
                </CoursesContext>
              ) : (
                <Redirect to="/" />
              )
            }
          />
          <Route
            path="/dashboard/editweblog"
            render={() =>
              !isEmpty(user) && user.isAdmin ? (
                <BlogContext>
                  <WeblogEdit />
                </BlogContext>
              ) : (
                <Redirect to="/" />
              )
            }
          />
          <Route
            path="/dashboard/usermanager"
            render={() =>
              !isEmpty(user) && user.isAdmin ? (
                <UserManage />
              ) : (
                <Redirect to="/" />
              )
            }
          />
        </DashboardLayout>
      </Route>
      <Route path={["/"]}>
        {/*  Main pages ........................................ */}
        <MainLayout>
          <Switch>
            <Route path="/forget-pass" component={ForgetPass} />
            <Route path="/blog-post/:id" component={BlogPost} />
            <Route path="/course/:id" component={Course} />
            <Route path="/buy-vip" component={MainBuyVip} />
            <Route path="/laws" component={Laws} />
            <Route path="/about-us" component={About} />
            <Route path="/contact-us" component={ContactUs} />
            <Route path="/weblog" component={BlogList} />
            <Route path="/courses" component={Courses} />
            <Route path="/profile" component={Profile} />
            <Route
              path="/register"
              render={() => (
                <UserContext>
                  <Register user={user} />
                </UserContext>
              )}
            />
            <Route
              path="/login"
              render={() => (
                <UserContext>
                  <Login user={user} />
                </UserContext>
              )}
            />
            <Route path="/logout" component={Logout} />
            <Route path="/" exact component={MainContent} />
            <Route path="*" exact component={NotFound404} />
          </Switch>
        </MainLayout>
      </Route>
    </Switch>
  );
};

export default Endless;
