import React, { useState } from "react";
import { paginate } from "../utils/paginate";
import { dashContext } from "./dashContext";
import AddPostModal from "../components/admin/modals/AddPostModal";
import EditPostModal from "../components/admin/modals/EditPostModal";
import { useSelector } from "react-redux";
import DeletePostModal from "../components/admin/modals/DeletePostModal";

const BlogContext = ({ children }) => {
  const blogListProvider = useSelector(state => state.blogList);
  // states
  const [perPage] = useState(7);
  const [currentPage, setCurrentPage] = useState(1);
  const [currentSinglePost, setCurrentSinglePost] = useState({});
  const [editSinglePostModal, setEditSinglePostModal] = useState(false);
  const [deleteSinglePostModal, setDeleteSinglePostModal] = useState(false);
  const [newSinglePostModal, setNewSinglePostModal] = useState(false);
  // new Post
  const openNewSinglePostModal = () => setNewSinglePostModal(true);
  const closeNewSinglePostModal = () => setNewSinglePostModal(false);
  // delete psot
  const openDeleteSinglePostModal = singlePost => {
    setDeleteSinglePostModal(true);
    setCurrentSinglePost(singlePost);
  };
  const closeDeleteSinglePostModal = () => {
    setDeleteSinglePostModal(false);
  };
  // singlePost updateEdit
  const openEditSinglePostModal = singlePost => {
    setEditSinglePostModal(true);
    setCurrentSinglePost(singlePost);
  };
  const closeEditSinglePostModal = () => {
    setEditSinglePostModal(false);
  };
  // pagination
  const handlePageChange = page => {
    setCurrentPage(page);
  };
  // paginate utils
  const blogListIndex = paginate(blogListProvider, currentPage, perPage);
  //   return ..........................................................
  return (
    <dashContext.Provider
      value={{
        blogListProvider,
        currentPage,
        perPage,
        handlePageChange,
        blogListIndex,
        openNewSinglePostModal,
        openEditSinglePostModal,
        openDeleteSinglePostModal
      }}
    >
      <AddPostModal
        showModal={newSinglePostModal}
        closeModal={closeNewSinglePostModal}
      />
      <EditPostModal
        showModal={editSinglePostModal}
        closeModal={closeEditSinglePostModal}
        post={currentSinglePost}
      />
      <DeletePostModal
        showModal={deleteSinglePostModal}
        closeModal={closeDeleteSinglePostModal}
        post={currentSinglePost}
      />
      {children}
    </dashContext.Provider>
  );
};
export default BlogContext;
