import React, { useState } from "react";
import { paginate } from "../utils/paginate";
import { dashContext } from "./dashContext";
import AddCourseModal from "../components/admin/modals/AddCourseModal";
import EditCourseModal from "../components/admin/modals/EditCourseModal";
import { useSelector } from "react-redux";
import DeleteCourseModal from "../components/admin/modals/DeleteCourseModal";

const CoursesContext = ({ children }) => {
  const coursesProvider = useSelector(state => state.courses);
  // states
  const [currentPage, setCurrentPage] = useState(1);
  const [perPage] = useState(7);
  const [currentCourse, setCurrentCourse] = useState({});
  const [newCourseModal, setNewCourseModal] = useState(false);
  const [deleteCourseModal, setDeleteCourseModal] = useState(false);
  const [editCourseModal, setEditCourseModal] = useState(false);
  // new course
  const openNewCourseModal = () => setNewCourseModal(true);
  const closeNewCourseModal = () => setNewCourseModal(false);
  // delete course
  const openDeleteCourseModal = course => {
    setDeleteCourseModal(true);
    setCurrentCourse(course);
  };
  const closeDeleteCourseModal = () => {
    setDeleteCourseModal(false);
  };
  // course updateEdit
  const openEditCourseModal = course => {
    setEditCourseModal(true);
    setCurrentCourse(course);
  };
  const closeEditCourseModal = () => {
    setEditCourseModal(false);
  };
  // pagination
  const handlePageChange = page => {
    setCurrentPage(page);
  };
  // paginate utils
  const coursesIndex = paginate(coursesProvider, currentPage, perPage);
  //   return ..........................................................
  return (
    <dashContext.Provider
      value={{
        coursesProvider,
        currentPage,
        perPage,
        handlePageChange,
        coursesIndex,
        openNewCourseModal,
        openEditCourseModal,
        openDeleteCourseModal,
      }}
    >
      <AddCourseModal
        showModal={newCourseModal}
        closeModal={closeNewCourseModal}
      />
      <EditCourseModal
        showModal={editCourseModal}
        closeModal={closeEditCourseModal}
        course={currentCourse}
      />
      <DeleteCourseModal
        showModal={deleteCourseModal}
        closeModal={closeDeleteCourseModal}
        course={currentCourse}
      />
      {children}
    </dashContext.Provider>
  );
};
export default CoursesContext;
