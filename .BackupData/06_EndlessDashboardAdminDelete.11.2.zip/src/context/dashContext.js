import { createContext } from 'react'

export const dashContext = createContext({
    currentPage: 1,
    setCurrentPage: () => { },
    perPage: 5,
    handlePageChange: () => { },
    coursesProvider: [],
    currentCourse: {},
    openNewCourseModal: () => { },
    openEditCourseModal: () => { },
    openDeleteCourseModal: () => { },
    coursesIndex: [],
    filteredCourses: [],
    sortCoursesAsc: () => { },
    sortCoursesDes: () => { },
    blogListProvider: [],
    currentSinglePost: {},
    openNewSinglePostModal: () => { },
    openEditSinglePostModal: () => { },
    openDeleteSinglePostModal: () => { },
    blogListIndex: [],
    filteredBlogList: [],
    sortBlogListAsc: () => { },
    sortBlogListDes: () => { },
});

