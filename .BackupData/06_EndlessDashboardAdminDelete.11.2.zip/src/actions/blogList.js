import { deleteSinglePost, getBlogList, newSinglePost, updateSinglePost } from "../services/blogServices"
import { successMessage, warningMessage } from "../utils/messageToast";

export const getAllBlogList = () => {
    return async dispatch => {
        const { data } = await getBlogList();
        await dispatch({
            type: "INIT_WEBLOG",
            payload: data.blogList
        });
    }
}

export const createNewSinglePost = (singlePost) => {
    return async (dispatch, getState) => {
        const blogList = [...getState().blogList]
        try {
            const { data, status } = await newSinglePost(singlePost);
            if (status === 201) successMessage("پست با موفقیت ساخته شد");
            await dispatch({
                type: "ADD_POST",
                payload: [...blogList, data.singlePost],
            });
        } catch (ex) {
            await dispatch({
                type: "ADD_POST",
                payload: [...blogList],
            });
        }
    };
};

export const handleSinglPostUpdate = (singlePostId, updatedSinglePost) => {
    return async (dispatch, getState) => {
        const blogList = [...getState().blogList]
        const updatedBlogList = [...blogList];
        // find singlePost
        const singlePostIndex = updatedBlogList.findIndex(singlePost => singlePost._id === singlePostId)
        let singlePost = updatedBlogList[singlePostIndex];
        // updated
        singlePost = { ...Object.fromEntries(updatedSinglePost) };
        updatedBlogList[singlePostIndex] = singlePost;
        // dispatch data
        try {
            // first update singlePost
            await dispatch({
                type: "UPDATE_POST",
                payload: [...updatedBlogList],
            });
            // next post
            const { data, status } = await updateSinglePost(singlePostId, updatedSinglePost)
            // console.log(data)
            if (status === 200) {
                successMessage("پست با موفقیت به روزرسانی شد")
            }
        } catch (ex) {
            await dispatch({ type: "UPDATE_POST", payload: [...blogList] });
        }
    }
}

export const handleSinglePostDelete = (singlePostId) => {
    return async (dispatch, getState) => {
        const blogList = [...getState().blogList]
        const filteredBlogList = blogList.filter(singlePost => singlePost._id !== singlePostId)
        try {
            await dispatch({
                type: "DELETE_POST",
                payload: [...filteredBlogList]
            })
            const { status } = await deleteSinglePost(singlePostId)
            if (status === 200) {
                warningMessage("دوره با موفقیت حذف شد")
            }
        } catch (ex) {
            await dispatch({
                type: "DELETE_POST",
                payload: [...blogList]
            })
        }
    }
}
