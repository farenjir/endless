import React, { useState, Fragment } from "react";
import { Link } from "react-router-dom";
import { useSelector } from "react-redux";
import { isEmpty } from "lodash";
// antDesign
import "antd/dist/antd.css";
import { Layout, Menu } from "antd";
import {
  DesktopOutlined,
  PieChartOutlined,
  FileOutlined,
  TeamOutlined,
  UserOutlined,
} from "@ant-design/icons";
import MenuItem from "antd/lib/menu/MenuItem";

const DashSidebar = () => {
  const user = useSelector(state => state.user);
  // collapse actions
  const [collapsed, setCollapsed] = useState(true);
  const { Sider } = Layout;
  // handels
  const onCollapse = collapsed => {
    setCollapsed(collapsed);
  };
  // styles
  const navIcons = {
    fontSize: "20px",
  };
  // collapsed in minWidth
  //   let winWidth = window.innerWidth;
  //   if (winWidth < 768) {
  //     setCollapsed(true);
  //   }
  return (
    <Sider
      theme="dark"
      collapsible
      collapsed={collapsed}
      onCollapse={onCollapse}
    >
      <Link to="/">
        <div class="mx-3 my-2">
          {!collapsed ? (
            <span>
              <strong className="text-white mx-3">اندلس</strong>
            </span>
          ) : null}
          <img
            class="img-fluid rounded"
            src="/assets/images/customer-img.jpg"
            width="50px"
            alt="Logo"
          />
        </div>
      </Link>
      <Menu
        theme="dark"
        defaultSelectedKeys={["1"]}
        mode="inline"
        style={{ direction: "ltr" }}
      >
        <Menu.Item
          style={{ marginTop: "6px" }}
          key="1"
          icon={<PieChartOutlined style={navIcons} />}
        >
          <Link to="/dashboard">داشبورد</Link>
        </Menu.Item>
        <Menu.Item
          className="mt-3"
          key="2"
          title="دوره ها"
          icon={<DesktopOutlined style={navIcons} />}
        >
          <Link to="/dashboard/courses">دوره ها</Link>
        </Menu.Item>
        <MenuItem
          key="3"
          icon={<UserOutlined style={navIcons} />}
          title="خبرنامه"
          className="mt-3"
        >
          <Link>خبرنامه</Link>
        </MenuItem>
        <MenuItem
          key="4"
          icon={<TeamOutlined style={navIcons} />}
          title="پیام ها"
          className="mt-3"
        >
          پیام ها
        </MenuItem>
        <MenuItem
          key="5"
          icon={<TeamOutlined style={navIcons} />}
          title="اشتراک ویژه"
          className="mt-3"
        >
         <Link to="/dashboard/vip"> اشتراک ویژه</Link>
        </MenuItem>
        {!isEmpty(user) && user.isAdmin ? (
          <Fragment>
            {" "}
            <Menu.Item
              className="mt-3"
              key="6"
              icon={<DesktopOutlined style={navIcons} />}
            >
              <Link to="/dashboard/editcourses">مدیریت دوره ها </Link>
            </Menu.Item>
            <MenuItem
              key="7"
              icon={<UserOutlined style={navIcons} />}
              title="پیام ها"
              className="mt-3"
            >
              <Link to="/dashboard/editweblog">مدیریت خبرنامه</Link>
            </MenuItem>
            <Menu.Item
              key="8"
              icon={<FileOutlined style={navIcons} />}
              className="mt-3"
            >
              <Link to="/dashboard/usermanager">مدیریت کاربران</Link>
            </Menu.Item>
          </Fragment>
        ) : null}
      </Menu>
    </Sider>
  );
};
export default DashSidebar;
