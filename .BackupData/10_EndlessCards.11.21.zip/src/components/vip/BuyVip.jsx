import React from "react";

const BuyVip = () => {
  return (
    <section>
      <div class="container">
        <div class="block-heading text-center py-4">
          <h2>خرید اشتراک ویژه</h2>
          <p>
            تاکنون مجموعه اندلس توانسته دوره در زمینه های طراحی و گرافیک تولید
            نماید
          </p>
        </div>
        <div class="row justify-content-center text-right">
          <div class="col-md-5 col-lg-4">
            <div class="clean-pricing-item">
              <div class="heading">
                <h3>معمولی</h3>
              </div>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
              <div>
                <h5>
                  <small>دسترسی به : </small>
                  <span>
                    <span className="badge-warning badge-pill badge">9</span>{" "}
                    دوره
                  </span>
                </h5>
                <h4>
                  <span>Duration:</span>
                  <span>30 Days</span>
                </h4>
                <h4>
                  <span>Storage:</span>
                  <span>10GB</span>
                </h4>
              </div>
              <div>
                <h4>$25</h4>
              </div>
              <button class="btn btn-outline-primary btn-block" type="button">
                خرید
              </button>
            </div>
          </div>
          <div class="col-md-5 col-lg-4">
            <div class="clean-pricing-item">
              <div class="ribbon">
                <span>پیشنهاد اندلس</span>
              </div>
              <div class="heading">
                <h3>ویژه</h3>
              </div>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
              <div>
                <h4>
                  <span>دسترسی به : </span>
                  <span>Yes</span>
                </h4>
                <h4>
                  <span>Duration:</span>
                  <span>60 Days</span>
                </h4>
                <h4>
                  <span>Storage:</span>
                  <span>50GB</span>
                </h4>
              </div>
              <div>
                <h4>$50</h4>
              </div>
              <button class="btn btn-primary btn-block" type="button">
                خرید
              </button>
            </div>
          </div>
          <div class="col-md-5 col-lg-4">
            <div class="clean-pricing-item">
              <div class="heading">
                <h3>نامحدود</h3>
              </div>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
              <div>
                <h4>
                  <span>دسترسی به : </span>
                  <span>Yes</span>
                </h4>
                <h4>
                  <span>Duration:</span>
                  <span>120 Days</span>
                </h4>
                <h4>
                  <span>Storage:</span>
                  <span>150GB</span>
                </h4>
              </div>
              <div>
                <h4>$150</h4>
              </div>
              <button class="btn btn-outline-primary btn-block" type="button">
                خرید
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
export default BuyVip;
