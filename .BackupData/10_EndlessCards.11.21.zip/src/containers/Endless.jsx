import React, { useEffect } from "react";
// redux
import { useDispatch, useSelector } from "react-redux";
// router
import { Switch, Route, Redirect } from "react-router-dom";
// context
import UserContext from "../context/userContext";
// jwt
import { addUser, clearUser } from "../actions/user";
import { isEmpty } from "lodash";
// utils
import { decodeToken } from "../utils/decodeToken";
// dashboardLayot
import DashboardLayout from "../components/layouts/DashboardLayout";
import DashboardHome from "../components/home/DashboardHome";
// adminDash
import WeblogEdit from "../components/admin/WeblogEdit";
import CoursesEdit from "../components/admin/CoursesEdit";
import UserManage from "../components/admin/UserManage";
import CoursesContext from "../context/CoursesContext";
import BlogContext from "../context/BlogContext";
// user dashboard
import BuyVip from "../components/vip/BuyVip";
import DashCourses from "../components/course/dashboard/DashCourses";
//MainLayout
import MainLayout from "../components/layouts/MainLayout";
import MainContent from "../components/home/MainContent";
// other pages
import Logout from "../components/login/Logout";
import Login from "../components/login/Login";
import Profile from "../components/profile/Profile";
import Register from "../components/register/Register";
import BlogList from "../components/weblog/BlogList";
import About from "../components/about/About";
import ContactUs from "../components/contact/ContactUs";
import Laws from "../components/laws/Laws";
import BlogPost from "../components/weblog/BlogPost";
import ForgetPass from "../components/login/ForgetPass";
import Courses from "../components/course/Courses";
import Course from "../components/course/Course";
import NotFound404 from "../components/common/NotFound404";

const Endless = () => {
  const user = useSelector(state => state.user);
  // check token
  const dispatch = useDispatch();
  useEffect(() => {
    const checkToken = () => {
      const token = localStorage.getItem("token");
      if (token) {
        const decodedToken = decodeToken(token);
        const dateNow = Math.floor(Date.now() / 1000);
        if (decodedToken.payload.exp < dateNow) {
          localStorage.removeItem("token");
          dispatch(clearUser());
        } else {
          dispatch(addUser(decodedToken.payload.user));
        }
      }
    };
    checkToken();
  }, []);
  return (
    <Switch>
      <Route path={["/dashboard"]}>
        {/* dashboard ........................................ */}
        <DashboardLayout>
          <Route
            path="/dashboard"
            exact
            render={() =>
              isEmpty(user) ? <Redirect to="/" /> : <DashboardHome />
            }
          />
          <Route
            path="/dashboard/vip"
            render={() => (!isEmpty(user) ? <BuyVip /> : <Redirect to="/" />)}
          />
                    <Route
            path="/dashboard/courses"
            render={() => (!isEmpty(user) ? <DashCourses /> : <Redirect to="/" />)}
          />
          <Route
            path="/dashboard/editcourses"
            render={() =>
              !isEmpty(user) && user.isAdmin ? (
                <CoursesContext>
                  <CoursesEdit />
                </CoursesContext>
              ) : (
                <Redirect to="/" />
              )
            }
          />
          <Route
            path="/dashboard/editweblog"
            render={() =>
              !isEmpty(user) && user.isAdmin ? (
                <BlogContext>
                  <WeblogEdit />
                </BlogContext>
              ) : (
                <Redirect to="/" />
              )
            }
          />
          <Route
            path="/dashboard/usermanager"
            render={() =>
              !isEmpty(user) && user.isAdmin ? (
                <UserManage />
              ) : (
                <Redirect to="/" />
              )
            }
          />
        </DashboardLayout>
      </Route>
      <Route path={["/"]}>
        {/*  Main pages ........................................ */}
        <MainLayout>
          <Switch>
            <Route path="/forget-pass" component={ForgetPass} />
            <Route path="/blog-post/:id" component={BlogPost} />
            <Route path="/course/:id" component={Course} />
            <Route path="/laws" component={Laws} />
            <Route path="/about-us" component={About} />
            <Route path="/contact-us" component={ContactUs} />
            <Route path="/weblog" component={BlogList} />
            <Route path="/courses" component={Courses} />
            <Route path="/profile" component={Profile} />
            <Route
              path="/register"
              render={() => (
                <UserContext>
                  <Register user={user} />
                </UserContext>
              )}
            />
            <Route
              path="/login"
              render={() => (
                <UserContext>
                  <Login user={user} />
                </UserContext>
              )}
            />
            <Route path="/logout" component={Logout} />
            <Route path="/" exact component={MainContent} />
            <Route path="*" exact component={NotFound404} />
          </Switch>
        </MainLayout>
      </Route>
    </Switch>
  );
};

export default Endless;
