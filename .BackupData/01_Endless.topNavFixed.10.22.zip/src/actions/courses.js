import { getCourses } from "../services/courseSevices"

export const getAllCourses = () => {
    return async dispatch => {
        const { data } = await getCourses()
        dispatch({
            type: "INIT_COURSES",
            payload: data.courses
        })
    }
}