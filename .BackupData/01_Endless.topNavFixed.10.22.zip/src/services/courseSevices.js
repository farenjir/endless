import config from "./config.json";
import http from "./httpService";

export const getCourses = () => {
    return http.get(`${config.localApi}/courses`)
}

export const getCourse = (courseId) => {
    return http.get(`${config.localApi}/course/${courseId}`)
}

