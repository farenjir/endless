import config from "./config.json";
import http from "./httpService";

export const getBlogList = () => {
    return http.get(`${config.localApi}/singleposts`)
}

export const getPost = (singlePostId) => {
    return http.get(`${config.localApi}/singlepost/${singlePostId}`)
}

