import React, { Fragment } from "react";
import { useSelector } from "react-redux";
import { isEmpty } from "lodash";
import { NavLink } from "react-router-dom";

const TopNav = () => {
  const user = useSelector(state => state.user);
  return (
    <nav className="navbar px-3 navbar-expand-md fixed-top">
      <NavLink to="/" exact style={{ paddingRight: "85px" }}>
        <i className="fas fa-infinity icon-brand"></i>
        {/* <!-- <img className="nav-pills" src="./img/gearLogo.png" alt="Logo" /> --> */}
      </NavLink>
      <button
        className="navbar-toggler"
        type="button"
        data-toggle="collapse"
        data-target="#myNav"
      >
        <span className="nav-icon">
          <i className="fas fa-bars"></i>
        </span>
      </button>
      {/* <!-- navbar collaps --> */}
      <div className="navbar-collapse collapse text-right" id="myNav">
        <ul className="navbar-nav mx-auto mt-3 mt-md-0">
          <li className="nav-item icon-under">
            {" "}
            <NavLink
              to="/laws"
              activeStyle={{ color: "gold" }}
              className="nav-link"
            >
              قوانین سایت{" "}
            </NavLink>
          </li>
          <li className="nav-item icon-under">
            {" "}
            <NavLink
              to="/contact-us"
              activeStyle={{ color: "gold" }}
              className="nav-link"
            >
              تماس با ما
            </NavLink>
          </li>
          <li className="nav-item icon-under">
            {" "}
            <NavLink
              to="/about-us"
              activeStyle={{ color: "gold" }}
              className="nav-link"
            >
              درباره ما
            </NavLink>
          </li>
          <li className="nav-item icon-under">
            {" "}
            <NavLink
              to="/weblog"
              activeStyle={{ color: "gold" }}
              className="nav-link"
            >
              وبلاگ
              {"  "}
              <i className="fas fa-newspaper mx-1"></i>
            </NavLink>
          </li>
          <li className="nav-item icon-under">
            {" "}
            <NavLink
              to="/courses"
              activeStyle={{ color: "gold" }}
              className="nav-link"
            >
              دوره ها
              {"  "}
              <i className="fas fa-newspaper mx-1"></i>
            </NavLink>
          </li>
          {!isEmpty(user) ? (
            <li className="nav-item icon-under d-flex align-items-center justify-content-end  d-md-none">
              <NavLink
                to="/dashboard"
                activeStyle={{ color: "gold" }}
                className="nav-link d-md-none"
              >
                داشبورد
                <i className="fas fa-database mx-2"></i>
              </NavLink>
              <NavLink to="/logout" className="nav-link">
                <i class="fa fa-sign-out mx-3" aria-hidden="true"></i>
              </NavLink>{" "}
              <NavLink
                to="/profile"
                activeStyle={{ color: "gold" }}
                className="nav-link"
              >
                {user.fullname}
                <i className="fas fa-user mx-2"></i>
              </NavLink>
            </li>
          ) : (
            <Fragment>
              <li className="nav-item icon-under d-md-none">
                <NavLink
                  to="/register"
                  activeStyle={{ color: "gold" }}
                  className="nav-link"
                >
                  ثبت نام
                  {"  "}
                  <i className="fas fa-user-plus mx-1"></i>
                </NavLink>
              </li>
              <li className="nav-item icon-under d-md-none">
                <NavLink
                  to="/login"
                  activeStyle={{ color: "gold" }}
                  className="nav-link"
                >
                  ورود
                  {"  "}
                  <i className="fas fa-user-check mx-1"></i>
                </NavLink>
              </li>
            </Fragment>
          )}
          <li className="nav-item icon-under d-none d-md-block">
            <NavLink
              to="/"
              exact
              activeStyle={{ color: "gold" }}
              className="nav-link"
            >
              صفحه نخست
              {"  "}
              <i className="fa fa-home mx-1"></i>
            </NavLink>
          </li>
        </ul>
      </div>

      <div className="d-none d-md-inline-block text-right">
        <ul className="navbar-nav mx-auto mt-3 mt-md-0">
          {isEmpty(user) ? (
            <Fragment>
              {"  "}
              <li className="nav-item icon-under">
                <NavLink
                  to="/login"
                  activeStyle={{ color: "gold" }}
                  className="nav-link"
                >
                  ورود
                  {"  "}
                  <i className="fas fa-user-check mx-1"></i>
                </NavLink>
              </li>
              {"  "}
              <li className="nav-item icon-under">
                <NavLink
                  to="/register"
                  activeStyle={{ color: "gold" }}
                  className="nav-link"
                >
                  ثبت نام
                  {"  "}
                  <i className="fa fa-user-plus mx-1"></i>
                </NavLink>
              </li>
            </Fragment>
          ) : (
            <Fragment>
              <li className="nav-item icon-under">
                <NavLink
                  to="/dashboard"
                  activeStyle={{ color: "gold" }}
                  className="nav-link"
                >
                  داشبورد <i className="fas fa-database mx-2"></i>
                </NavLink>
              </li>
              <li className="nav-item icon-under">
                <NavLink
                  to="/profile"
                  activeStyle={{ color: "gold" }}
                  className="nav-link"
                >
                  {user.fullname} <i className="fas fa-user mx-2"></i>
                </NavLink>
              </li>
              <li className="nav-item icon-under">
                <NavLink to="/logout" className="nav-link">
                  <i class="fa fa-sign-in" aria-hidden="true"></i>
                </NavLink>
              </li>
            </Fragment>
          )}
        </ul>
      </div>
    </nav>
  );
};

export default TopNav;
