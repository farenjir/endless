import React, { useEffect } from "react";
// redux
import { useDispatch } from "react-redux";
// router
import { Switch, Route } from "react-router-dom";
// jwt
import { addUser, clearUser } from "../actions/user";
// utils
import { decodeToken } from "../utils/decodeToken";
//MainLayout
import MainLayout from "../components/layouts/MainLayout";
import MainContent from "../components/home/MainContent";
// other pages
import Logout from "../components/login/Logout";
import Login from "../components/login/Login";
import Profile from "../components/profile/Profile";
import Register from "../components/register/Register";
import BlogList from "../components/weblog/BlogList";
import About from "../components/about/About";
import ContactUs from "../components/contact/ContactUs";
import Laws from "../components/laws/Laws";
import BlogPost from "../components/weblog/BlogPost";
import ForgetPass from "../components/login/ForgetPass";
import Courses from "../components/course/Courses";
import Course from "../components/course/Course";

const Wallet = () => {
  // check token
  const dispatch = useDispatch();
  useEffect(() => {
    const token = localStorage.getItem("token");
    if (token) {
      const decodedToken = decodeToken(token);
      const dateNow = Math.floor(Date.now() / 1000);
      if (decodedToken.payload.exp < dateNow) {
        localStorage.removeItem("token");
        dispatch(clearUser());
      } else {
        dispatch(addUser(decodedToken.payload.user));
      }
    }
  }, []);
  // return ..........................................................................
  return (
    <MainLayout>
      <Switch>
        {/* other pages */}
        <Route path="/forget-pass" component={ForgetPass} />
        <Route path="/blog-post/:id" component={BlogPost} />
        <Route path="/course/:id" component={Course} />
        {/*  Main pages */}
        <Route path="/laws" component={Laws} />
        <Route path="/about-us" component={About} />
        <Route path="/contact-us" component={ContactUs} />
        <Route path="/weblog" component={BlogList} />
        <Route path="/courses" component={Courses} />
        <Route path="/register" component={Register} />
        <Route path="/profile" component={Profile} />
        <Route path="/login" component={Login} />
        <Route path="/logout" component={Logout} />
        <Route path="/" exact component={MainContent} />
      </Switch>
    </MainLayout>
  );
};

export default Wallet;
