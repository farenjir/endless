export const CoursesReducer = (state = [], action) => {
    switch (action.type) {
        case "INIT_COURSES":
            return [...action.payload]
        default:
            return state
    }
}