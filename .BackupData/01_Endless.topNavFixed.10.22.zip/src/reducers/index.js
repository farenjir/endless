import { combineReducers } from "redux"
// reducers
import { BlogListReducer } from "./blogList"
import { BlogSinglePostReducer } from "./blogSinglePost"
import { CourseReducer } from "./course"
import { CoursesReducer } from "./courses"
import { userReducer } from "./user"

// combine Reducers
export const reducers = combineReducers({
    blogList: BlogListReducer,
    blogPost: BlogSinglePostReducer,
    courses: CoursesReducer,
    course: CourseReducer,
    user: userReducer
})