import React, { useState } from "react";
import { Link } from "react-router-dom";
// import config from "../../services/config.json";
// redux
import { useSelector } from "react-redux";
// utils
import Pagination from "../common/Pagination";
import { paginate } from "../../utils/paginate";
import Helmet from "react-helmet";

const Courses = () => {
  // get courses
  const courses = useSelector(state => state.courses);
  // pagination
  const [perPage] = useState(5);
  const [currentPage, setCurrentPage] = useState(1);
  const handlePageChange = page => {
    setCurrentPage(page);
  };
  // paginate utils
  const coursesIndex = paginate(courses, currentPage, perPage);
  return (
    <main>
      <div className="container pt-3">
        <Helmet>
          <title>اندلس | دوره ها</title>
        </Helmet>
        <div className="text-center">
          <h2 className="text-info">دوره های آموزشی اندلس</h2>
          <p className="w-75 mx-auto text-success">
            تاکنون مجموعه اندلس توانسته با تولید{" "}
            <span className="badge-info badge-pill badge">
              {courses.length}
            </span>{" "}
            مطلب آموزشی در زمینه های طراحی و گرافیک گامی درجهت پیشرفت شما عزیزان
            بردارد
          </p>
        </div>
        <div className="bg-white p-5">
          <div className="row">
            {/* <!-- courses from SERVER--> */}
            {coursesIndex.map(course => (
              <div key={course._id} className="row my-3 course-card">
                <div className="col-lg-4 m-0 p-0">
                  <Link to={`/course/${course._id}`}>
                    <img
                      className="rounded img-fluid"
                      src="assets/images/imageAple.jpg"
                      alt="تصویر دوره یافت نشد"
                    />
                  </Link>
                </div>
                <div className="col-lg-8 p-4 text-right">
                  <h4>{course.title}</h4>
                  <div className="info">
                    <span className="text-muted">
                      {course.date} مدرس : {course.teacher}فرشید انجیلی{" "}
                    </span>
                    <span className="text-info">
                      <p> قیمت دوره : {course.price === 0 ? "رایگان" : course.price}</p>
                    </span>
                  </div>
                  <p>{course.info}</p>
                  <Link to={`/course/${course._id}`}>
                    <button
                      className="btn btn-outline-primary btn-sm mt-3"
                      type="button"
                    >
                      بیشتر بدانید
                    </button>
                  </Link>
                </div>
              </div>
            ))}
            {/* <!-- / courses from SERVER --> */}
          </div>
        </div>
        <Pagination
          objLength={courses.length}
          currentPage={currentPage}
          perPage={perPage}
          onPageChange={handlePageChange}
        />
      </div>
    </main>
  );
};

export default Courses;
